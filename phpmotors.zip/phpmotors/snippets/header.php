<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Fugaz+One&family=Goldman&display=swap" rel="stylesheet">
<div>
    <a href="/phpmotors/home.php"><img src="/phpmotors/images/site/logo.png" alt="logo_img" id="logo_img"></a>
    <button id="account_btn">My Account</button>
</div>
<nav>
    <ul id="header_ul">
        <li><a class="active" href="">Home</a></li>
        <li><a href="">Classic</a></li>
        <li><a href="">Sports</a></li>
        <li><a href="">SUV</a></li>
        <li><a href="">Trucks</a></li>
        <li><a href="">Used</a></li>
    </ul>
</nav>    